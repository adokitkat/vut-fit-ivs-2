#!/usr/bin/env python3
from mathematica import Math

def main():
    print(Math(input()))

if __name__=='__main__':
    main()