#!/usr/bin/env python3

from mathematica import Math
import sys

def __average__(lines,N):
    tmp=1.0 / N
    #average=sum(int(i) for i in lines)
    #for i in range(len(lines)):
    #    average+=lines[i]
    #tmp*=average
    return tmp

#def __deviation__(tmp,lines,N):
#    fraction= 1.0 / (N-1)
#    sum=Math(lines)
#    for i in range(len(lines)-1):
#        sum.__add__(lines[i],lines[i+1])

lines=sys.stdin.readlines()
N=len(lines)
for i in range(len(lines)):
    lines[i]=lines[i].replace('\n','')


tmp=__average__(lines,N)
#__deviation__(tmp,lines,N)
print(tmp)


